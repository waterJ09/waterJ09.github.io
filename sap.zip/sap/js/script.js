document.querySelectorAll('figure').forEach(function(item) {
    item.addEventListener('click', function() {
        // Event to be set
    });
});